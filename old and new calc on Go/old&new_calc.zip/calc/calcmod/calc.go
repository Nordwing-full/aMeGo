package calc

import "fmt"

func Sum() {
	var a int
	var b int
	fmt.Println("Введите первое число для сложения: ")
	fmt.Scan(&a)
	fmt.Println("Введите второе число для сложения: ")
	fmt.Scan(&b)
	result := a + b
	fmt.Println("Результат сложения =", result)
}

func Minu() {
	var a int
	var b int
	fmt.Println("Введите первое число для вычетания: ")
	fmt.Scan(&a)
	fmt.Println("Введите второе число для вычетания: ")
	fmt.Scan(&b)
	result := a - b
	fmt.Println("Результат вычетания =", result)
}

func Umn() {
	var a int
	var b int
	fmt.Println("Введите первое число для умножения: ")
	fmt.Scan(&a)
	fmt.Println("Введите второе число для умножения: ")
	fmt.Scan(&b)
	result := a * b
	fmt.Println("Результат умножения =", result)
}

func Del() {
	var a int
	var b int
	fmt.Println("Введите первое число для деления: ")
	fmt.Scan(&a)
	fmt.Println("Введите второе число для деления: ")
	fmt.Scan(&b)
	result := a / b
	fmt.Println("Результат деления =", result)
}
