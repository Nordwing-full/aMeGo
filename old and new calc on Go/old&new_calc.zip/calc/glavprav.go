package main

import (
	calc "calc/calcmod"
	"fmt"
)

func main() {
	var choose int
	fmt.Println("Введите число для выбора нужно математической операции от 1 до 4: ")
	fmt.Scan(&choose)
	if choose == 1 {
		calc.Sum()
	} else if choose == 2 {
		calc.Minu()
	} else if choose == 3 {
		calc.Umn()
	} else if choose == 4 {
		calc.Del()
	}
}
