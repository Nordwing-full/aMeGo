package main

import (
	calc "calc2/calcmod"
	"fmt"
)

func main() {
	var a float64
	var b float64
	var choose int
	fmt.Println("Введите число для выбора нужно математической операции от 1 до 4: ")
	fmt.Scan(&choose)
	if choose == 1 {
		fmt.Println("Введите первое число для сложения: ")
		fmt.Scan(&a)
		fmt.Println("Введите второе число для сложения: ")
		fmt.Scan(&b)
		result := calc.Sum(a, b)
		fmt.Printf("Ответ: %f", result)
	} else if choose == 2 {
		fmt.Println("Введите первое число для вычетания: ")
		fmt.Scan(&a)
		fmt.Println("Введите второе число для вычетания: ")
		fmt.Scan(&b)
		result := calc.Minu(a, b)
		fmt.Printf("Ответ: %f", result)
	} else if choose == 3 {
		fmt.Println("Введите первое число для умножения: ")
		fmt.Scan(&a)
		fmt.Println("Введите второе число для умножения: ")
		fmt.Scan(&b)
		result := calc.Umn(a, b)
		fmt.Printf("Ответ: %f", result)
	} else if choose == 4 {
		fmt.Println("Введите первое число для деления: ")
		fmt.Scan(&a)
		fmt.Println("Введите второе число для деления: ")
		fmt.Scan(&b)
		result := calc.Del(a, b)
		fmt.Printf("Ответ: %f", result)
	}
}
