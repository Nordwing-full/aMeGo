package calcnew

func Sum(a float64, b float64) float64 {
	return a + b
}

func Minu(a float64, b float64) float64 {
	return a - b
}

func Umn(a float64, b float64) float64 {
	return a * b
}

func Del(a float64, b float64) float64 {
	return a / b
}
